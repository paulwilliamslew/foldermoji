/* FolderMoji v1.3.10
 * Copyright © 2026 Paul Williams. All rights reserved.
 * Use is governed by LICENSE.txt included with this software.
 */
'use strict';

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: 'chrome://bookmarks/' }).catch(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL('bookmarks.html') });
  });
});
