# FolderMoji Changelog

## 1.3.10 — 27 August 2026

- Changed the How to use FolderMoji panel to a soft light-green background.
- Added a coordinating pale-green border and section dividers while preserving readable text contrast.
- Retained every emoji and all existing FolderMoji functionality.

## 1.3.9 — 27 August 2026

- Expanded the permanent left navigation guide with descriptions of sorting, folder drag-and-drop, Move destination search, visible location paths, duplicate-name warnings, and selective restore.
- Kept the existing selection, opening, safe deletion, and Ctrl+A safety guidance.
- Retained every emoji and all existing FolderMoji functionality.

## 1.3.8 — 27 August 2026

- Added drag-and-drop onto folder rows in the main bookmark list.
- Added a strong visual highlight when a folder row is a valid drop destination.
- Preserved folder contents when moving one folder into another.
- Blocked drops onto the source folder, another selected destination, or a descendant of the folder being moved.
- Retained sidebar-tree drag-and-drop, Move search, location paths, duplicate warnings, emojis, sorting, and recovery safeguards.

## 1.3.7 — 27 August 2026

- Added folder-name and hierarchy-path search to the Move to Folder dialog.
- Added a visible Location path beneath every bookmark and folder.
- Added duplicate-folder warnings for new folders and renamed folders, ignoring letter case and leading emojis.
- Listed the existing hierarchy locations inside duplicate warnings while allowing intentional duplicates.
- Strengthened post-move selection clearing so the selection action bar closes after a successful move.
- Retained all emojis, sorting modes, recovery records, and deletion safeguards.

## 1.3.6 — 27 August 2026

- Confirmed that Restore Selected restores only the selected bookmarks or folders; Ctrl+A is required before restoring every visible item.
- Made FolderMoji Trash visible beneath Other bookmarks in the expandable left folder tree while retaining the Restore Deleted Files shortcut.
- Replaced all current user-facing Transfer terminology with Move.
- Renamed the destination dialog to Move to Folder and its confirmation button to Move Here.
- Replaced dashed hierarchy markers with clean whitespace indentation in the destination list.
- Retained all emojis, sorting modes, recovery records, and deletion safeguards.

## 1.3.5 — 27 August 2026

- Replaced the sorting dropdown with four compact SVG buttons for A–Z, Z–A, newest first, and oldest first.
- Added visible selected-state styling and accessible labels to every sorting button.
- Restored **FolderMoji Trash** as the physical recovery folder beneath Chrome's protected Other bookmarks root.
- Retained **Restore Deleted Files** as the clearer sidebar recovery action.
- Changed the mascot icon background from black to deep emerald green for a friendlier, distinctive identity with strong white-face contrast.
- Retained all emojis, sorting behaviour, recovery records, and deletion safeguards.

## 1.3.4 — 27 August 2026

- Added Alphabetically, Reverse alphabetically, Recent, and Reverse recency sorting.
- Kept folders above bookmarks and ignored leading emojis during alphabetical sorting.
- Remembered the selected sorting mode locally.
- Enlarged the FolderMoji mascot and placed its white face on a high-contrast black square.
- Renamed the recovery folder to **Restore Deleted Files** and migrated the prior FolderMoji Trash or Trash & Recovery folder without duplicating it.
- Retained all existing emoji selections and deletion safeguards.

## 1.3.3 — 27 August 2026

- Fixed mascot branding image path in the manager header (`icons/foldermoji-48.png`).
- Added a permanent **Trash & Recovery** shortcut item in the sidebar navigation for instant access to deleted/misplaced items.
- Redesigned the **Transfer to Folder** (`#moveDialog`) modal with a clean, scrollable visual tree list that matches modern desktop interface aesthetics.
- Updated confirmation dialog terminology: replaced ambiguous "MOVE" strings with clear "Transfer" phrasing and simplified typed verification to `CONFIRM [X]`.
- Updated all internal version strings to v1.3.3.

## 1.3.2 — 27 August 2026

- Added a close-up sifaka face for Chrome toolbar and other small icon placements.
- Kept the complete mascot illustration in the FolderMoji page header.
- Made the Chrome toolbar icon open `chrome://bookmarks`, which loads FolderMoji while installed.
