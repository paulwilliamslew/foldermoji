# FolderMoji Chrome Web Store Listing Draft

Current release: 1.3.10

## Product name

FolderMoji

## Short description

Give Chrome bookmark folders a visual identity with meaningful emojis, private suggestions, and distinctive text colours.

## Detailed description

FolderMoji helps you recognize and organize bookmark folders at a glance.

Choose meaningful Unicode emojis from visual interest collections, use private suggestions calculated on your device, and assign distinctive text colours inside the FolderMoji bookmark manager. Emojis placed in folder names remain part of ordinary Chrome bookmark titles and may synchronize through Chrome Sync. Folder colours appear inside FolderMoji.

Organize large collections with guarded Ctrl-click, Shift-click, and Ctrl+A selection, batch Move, drag-and-drop, and a recoverable FolderMoji Trash. Select All is limited to the items currently displayed, and FolderMoji warns about nested contents before large operations.

FolderMoji requests only the permissions needed for its stated purpose:

- Bookmarks: display and perform user-requested bookmark and folder actions.
- Storage: remember folder colours and private suggestion preferences.

FolderMoji contains no advertising or analytics and does not transmit bookmark titles, URLs, browsing history, emoji selections, or folder-colour choices to the developer or an external AI service.

## Single purpose

FolderMoji provides visual organization and management of Chrome bookmarks and bookmark folders.

## Privacy disclosure checklist

- Host `PRIVACY.md` at a stable public HTTPS URL before submission.
- Enter that URL in the Chrome Web Store privacy fields.
- Declare use of the bookmarks and storage permissions accurately.
- Confirm that no user data is sold, used for advertising, or transferred to external AI services.
- Reassess all declarations before adding analytics, accounts, cloud backup, payments, or external services.

## Ownership notice

FolderMoji is the product name used by Paul Williams. The original FolderMoji software and materials are copyright © 2026 Paul Williams. All rights reserved. Free use is governed by the FolderMoji Proprietary Free-Use Licence.

## Non-affiliation notice

FolderMoji is not affiliated with, endorsed by, or sponsored by Google LLC or the Unicode Consortium.
