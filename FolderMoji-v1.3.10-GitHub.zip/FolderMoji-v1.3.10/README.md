# FolderMoji 1.3.10

**Give every bookmark folder a visual identity.**

FolderMoji is a privacy-conscious Chrome Manifest V3 extension that helps people recognize and organize bookmark folders using meaningful Unicode emojis, private on-device suggestions, and folder text colours.

## Key Features & Polish
- **Focused Folder Editor:** Category emojis and private smart suggestions remain prominent, without unused pinning or custom-emoji controls.
- **Expanded Text Colours:** Sixteen familiar, named colours ranging from black and primary colours to teal, indigo, tan, and white.
- **Clear Save Action:** A squared, dark Save Changes button provides a stable visual endpoint.
- **Focused FolderMoji Design:** Soft grey cards, subtle shadows, clear typography, and a distraction-free editing workflow.
- **Large High-Visibility Emojis:** 100% larger emoji buttons (52px wide, 28px glyph) with an interactive scale expansion (+24%) and layered shadow on hover.
- **Direct Category Placement:** Top-level theme gallery covering modern digital aesthetics, anime & manga, East-West café culture, and urban lifestyle.
- **Chrome Bookmarks Sync:** Emojis synchronize cleanly via standard Chrome bookmarks. Folder text color styling is preserved inside the manager interface.
- **Guarded Multi-Selection:** Ctrl-click selects individual items, Shift-click selects a range, and Ctrl+A selects only the items currently displayed.
- **Visible Selection Controls:** Every row includes a checkbox, and the full row responds to selection gestures.
- **On-Screen Guide:** The left navigation explains selection, movement, opening, Trash, and the Ctrl+A safeguard.
- **Expanded On-Screen Help:** The left navigation also explains sorting, direct folder drops, destination search, location paths, duplicate warnings, and selective restore.
- **Soft Green Help Panel:** The permanent left-navigation instructions use a calm light-green background with clear text contrast.
- **FolderMoji Mascot:** A Verreaux’s sifaka holding a folder identifies the extension in Chrome and in the manager header.
- **One-Click Toolbar Access:** The close-up sifaka toolbar icon opens Chrome Bookmarks, which FolderMoji replaces while installed.
- **Flexible Sorting:** Order folders and bookmarks alphabetically, reverse alphabetically, by most recent, or by reverse recency.
- **High-Contrast Mascot:** The enlarged white sifaka face sits on a deep emerald-green square for clearer toolbar and navigation visibility.
- **FolderMoji Trash:** Recover moved items from a dedicated FolderMoji Trash subfolder inside Chrome's protected Other bookmarks root using the Restore Deleted Files sidebar action.
- **Selective Restore:** Restore Selected affects only checked or selected items. To restore every visible recovery item, use Ctrl+A and then Restore Selected.
- **Clear Move Language:** Move Selected, Move to Folder, and Move Here use familiar bookmark-management terminology with a clean indented destination hierarchy.
- **Searchable Destinations:** Search the Move to Folder list by folder name or any part of its hierarchy path.
- **Visible Locations:** Every bookmark and folder displays its parent hierarchy beneath its title.
- **Duplicate Warnings:** Before creating or renaming a folder, FolderMoji warns about matching names and identifies their existing locations.
- **Direct Folder Drop:** Drag a folder such as PEMF directly onto a destination folder such as Health in the main list or left navigation.
- **Batch Organization:** Move selected items through the Move dialog or drag them onto a folder in the navigation tree.
- **Recoverable Trash:** Ordinary deletion moves bookmarks and folders to FolderMoji Trash instead of immediately destroying them.
- **Large-Operation Warnings:** FolderMoji counts nested items and requires typed confirmation for unusually large or permanent operations.

## Installation in Chrome

1. Extract the `FolderMoji-v1.3.10.zip` archive.
2. Open Google Chrome and visit `chrome://extensions`.
3. Enable **Developer mode** in the top right corner.
4. Click **Load unpacked** and select the extracted folder.
5. Open your bookmarks manager (`chrome://bookmarks` or via the menu).

## Privacy

FolderMoji performs its recommendation logic on the user's device. It does not contain advertising or analytics and does not transmit bookmark titles, URLs, browsing history, or emoji selections to Paul Williams or any external AI service. See `PRIVACY.md` for the complete disclosure.

## Ownership and permitted use

Copyright © 2026 Paul Williams. All rights reserved. FolderMoji is the product name used by Paul Williams for this software and its associated materials. The software is free to install and use under the limited licence in `LICENSE.txt`; it is not open-source software and may not be republished, resold, redistributed, or incorporated into another product without prior written permission.

See `TERMS.md`, `NOTICE.txt`, and `ATTRIBUTIONS.md` for additional information.
