/* FolderMoji v1.3.10
 * Copyright © 2026 Paul Williams. All rights reserved.
 * Use is governed by LICENSE.txt included with this software.
 */
'use strict';

const COLOURS = [
  ['#1d1d1f', 'Black'],
  ['#6e6e73', 'Grey'],
  ['#8b4513', 'Brown'],
  ['#ff3b30', 'Red'],
  ['#ff2d55', 'Pink'],
  ['#ff9500', 'Orange'],
  ['#ffcc00', 'Yellow'],
  ['#34c759', 'Green'],
  ['#00a86b', 'Emerald'],
  ['#00c7be', 'Teal'],
  ['#32ade6', 'Sky Blue'],
  ['#0071e3', 'Blue'],
  ['#5856d6', 'Indigo'],
  ['#af52de', 'Purple'],
  ['#a2845e', 'Tan'],
  ['#ffffff', 'White']
];

const PACKS = {
  'Digital Art & Aesthetics': [
    ['🎨','digital painting art'],['🖌️','brush calligraphy procreate'],['✨','sparkle aesthetic glitter'],
    ['🔮','cyber aesthetic vaporwave'],['🌆','synthwave city dusk'],['🌌','galaxy dreamcore'],
    ['👾','pixel art retro 8bit'],['🪞','aesthetic mirror clean'],['🪩','disco shiny aesthetic'],
    ['🕯️','dark academia mood'],['🎀','coquette cute style'],['🕶️','cyberpunk futuristic neon']
  ],
  'Anime, Manga & Pop Culture': [
    ['🌸','sakura cherry blossom'],['🍡','dango anime snack'],['🦊','kitsune fox spirit'],
    ['⛩️','torii shrine gate'],['🍙','onigiri riceball'],['🏮','red lantern izakaya'],
    ['🎴','hanafuda anime cards'],['🥟','dim sum dumpling'],['🐉','oriental dragon fantasy'],
    ['🎏','koinobori carp streamer'],['🐱','neko cat cute kawaii'],['🥋','martial arts dojo']
  ],
  'Food & Café Culture (East & West)': [
    ['☕','espresso coffee latte'],['🍵','matcha green tea oolong'],['🧋','boba bubble tea'],
    ['🥐','croissant bakery'],['🍜','ramen noodle soup'],['🍣','sushi nigiri'],
    ['🍰','shortcake bakery dessert'],['🥞','souffle pancakes brunch'],['🫘','coffee beans roast'],
    ['🍲','hotpot stew asian'],['🥑','avocado toast brunch'],['🥟','dumplings gyoza bao']
  ],
  'Urban, Street & Lifestyle': [
    ['🏙️','city skyline metropolis'],['👟','sneakers kicks streetstyle'],['🛹','skateboarding street'],
    ['🎧','street audio lofi beats'],['📸','film street photography'],['🚇','metro subway transit'],
    ['🧳','travel luggage nomadic'],['🍁','autumn maple chill'],['🗽','city iconic landmarks'],
    ['🎋','bamboo serene zen'],['🪷','lotus blossom peaceful'],['☕','street cafe patio']
  ],
  'Gaming & Tech Trends': [
    ['🎮','gaming console esports'],['🕹️','arcade retro gaming'],['🤖','ai bot robotics'],
    ['💻','coding developer setup'],['⌨️','mechanical keyboard custom'],['📱','social media smartphone'],
    ['🌐','web digital internet'],['⚙️','tech engineering setup'],['⚡','fast performance viral'],
    ['🎧','streaming gaming headset'],['🔋','power tech charge'],['🖥️','battlestation monitor']
  ],
  'Mind, Learning & Studies': [
    ['📚','study session books'],['📖','reading novel manhwa'],['🧠','psychology cognitive mind'],
    ['📝','study notes journaling'],['💡','creative inspiration ideas'],['🎓','college academia university'],
    ['✏️','sketching stationary study'],['📜','traditional scroll wisdom'],['🍵','focus tea ritual'],
    ['🏛️','classical architecture museum'],['🔍','research analysis focus'],['🗓️','planner productivity routine']
  ],
  'Wellness & Zen': [
    ['🧘','meditation mindfulness zen'],['🌿','botanical herbal indoor plants'],['🫖','tea pot ceremony gongfu'],
    ['🌊','minimal ocean wave calm'],['🌅','golden hour sunrise'],['🌙','lofi night cozy'],
    ['🎋','bamboo tranquility'],['🪔','aromatherapy candle scent'],['🤍','minimalist clean white'],
    ['🪴','monstera houseplant aesthetic'],['🧼','self-care routine clean'],['🕊️','peace serene calmness']
  ]
};

const ASSOCIATIONS = [
  {words:['coffee','cafe','espresso','matcha','latte'],emojis:['☕','🍵','🧋','🥐','🍰','✨']},
  {words:['art','design','drawing','sketch','illustration','aesthetic'],emojis:['🎨','🖌️','✨','🌆','👾','🎀','🖼️']},
  {words:['anime','manga','japan','asia','korea'],emojis:['🌸','🍡','🏮','🍙','⛩️','🦊','🧋']},
  {words:['music','song','beats','lofi','playlist'],emojis:['🎧','🎵','🎤','🎹','🪩','✨']},
  {words:['gaming','game','esports','stream'],emojis:['🎮','🕹️','👾','⚡','🎧','💻']},
  {words:['tech','code','ai','dev','programming'],emojis:['💻','⌨️','🤖','🌐','⚙️','⚡']},
  {words:['book','reading','study','psychology','research'],emojis:['📚','📖','🧠','📝','💡','🎓']},
  {words:['travel','trip','flight','city'],emojis:['✈️','🏙️','🧳','🗺️','📸','🍁']},
  {words:['tea','herbal','zen','wellness','nature'],emojis:['🍵','🌿','🫖','🧘','🪷','🪴']}
];

const colourKey = id => `folderColour:${id}`;
const TRASH_TITLE = 'FolderMoji Trash';
const LEGACY_TRASH_TITLES = new Set(['Restore Deleted Files', 'Trash & Recovery']);
const TRASH_RECORDS_KEY = 'folderMojiTrashRecords';
const TRASH_FOLDER_ID_KEY = 'folderMojiTrashFolderId';
const SORT_MODE_KEY = 'folderMojiSortMode';

const state = { 
  tree: null, 
  folderId: '1', 
  colours: {}, 
  usage: {}, 
  lastEmoji: '', 
  expanded: new Set(), 
  selected: new Set(),
  visibleItems: [],
  selectionAnchorId: null,
  allVisibleSelected: false,
  trashFolderId: null,
  trashRecords: {},
  sortMode: 'alphabetical',
  editing: null, 
  moving: null, 
  movingIds: [],
  moveDestinations: [],
  mode: 'edit' 
};

const $ = selector => document.querySelector(selector);

document.addEventListener('DOMContentLoaded', initialise);

async function initialise() {
  buildPickers();
  bindEvents();
  await refresh();
}

function bindEvents() {
  $('#searchInput').addEventListener('input', debounce(handleSearch, 180));
  $('#addFolderButton').addEventListener('click', () => openEditor('new-folder'));
  $('#addBookmarkButton').addEventListener('click', () => openEditor('new-bookmark'));
  $('#editorForm').addEventListener('submit', saveEditor);
  $('#moveForm').addEventListener('submit', saveMove);
  $('#moveSearch').addEventListener('input', event => renderMoveDestinations(event.target.value));
  $('#clearSelectionButton').addEventListener('click', clearSelection);
  $('#titleInput').addEventListener('input', renderSuggestions);
  $('#interestSelect').addEventListener('change', renderInterestPack);
  $('#removeEmoji').addEventListener('click', removeLeadingEmoji);
  $('#customColour').addEventListener('input', event => selectColour(event.target.value));
  $('#trashShortcut').addEventListener('click', navigateToTrash);
  $('#trashShortcut').addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      navigateToTrash();
    }
  });
  document.querySelectorAll('[data-sort-mode]').forEach(button => {
    button.addEventListener('click', async () => {
      state.sortMode = button.dataset.sortMode;
      await chrome.storage.local.set({[SORT_MODE_KEY]: state.sortMode});
      updateSortButtons();
      renderFolderTree();
      $('#searchInput').value.trim() ? handleSearch() : renderCurrentFolder();
    });
  });
  document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => $('#editorDialog').close()));
  document.querySelectorAll('[data-close-move]').forEach(button => button.addEventListener('click', () => $('#moveDialog').close()));
  document.addEventListener('keydown', handleKeyboardSelection);
  chrome.bookmarks.onCreated.addListener(refresh);
  chrome.bookmarks.onRemoved.addListener(refresh);
  chrome.bookmarks.onChanged.addListener(refresh);
  chrome.bookmarks.onMoved.addListener(refresh);
}

function buildPickers() {
  $('#interestSelect').replaceChildren(...Object.keys(PACKS).map(name => {
    const option = document.createElement('option'); 
    option.value = name; 
    option.textContent = name; 
    return option;
  }));
  renderInterestPack();
  $('#suggestedEmojiGrid').replaceChildren(makeEmojiButton('📁'));
  $('#colourGrid').replaceChildren(...COLOURS.map(([colour, name]) => {
    const button = document.createElement('button');
    button.type = 'button'; 
    button.className = 'colour-button'; 
    button.dataset.colour = colour;
    button.style.backgroundColor = colour; 
    button.title = name;
    button.setAttribute('aria-label', name);
    button.addEventListener('click', () => selectColour(colour));
    return button;
  }));
}

function makeEmojiButton(emoji) {
  const button = document.createElement('button');
  button.type = 'button'; 
  button.className = `emoji-button${state.lastEmoji === emoji ? ' chosen' : ''}`; 
  button.textContent = emoji;
  button.title = `Select ${emoji}`; 
  button.addEventListener('click', () => applyEmoji(emoji));
  return button;
}

function renderInterestPack() {
  const items = PACKS[$('#interestSelect').value] || Object.values(PACKS)[0];
  $('#interestEmojiGrid').replaceChildren(...items.map(([emoji]) => makeEmojiButton(emoji)));
}

function renderSuggestions() {
  const title = stripLeadingEmoji($('#titleInput').value).toLowerCase();
  const matches = ASSOCIATIONS.filter(entry => entry.words.some(word => title.includes(word))).flatMap(entry => entry.emojis);
  const personal = Object.keys(state.usage).sort((a,b) => (state.usage[b] || 0) - (state.usage[a] || 0));
  const suggestions = [...new Set(matches.length ? [...matches,...personal] : [...personal,'📁','📌','⭐','❤️','✨'])]
    .sort((a,b) => (state.usage[b] || 0) - (state.usage[a] || 0)).slice(0, 8);
  $('#suggestedEmojiGrid').replaceChildren(...suggestions.map(emoji => makeEmojiButton(emoji)));
}

async function refresh() {
  const [tree, stored, local] = await Promise.all([
    chrome.bookmarks.getTree(), 
    chrome.storage.sync.get(null), 
    chrome.storage.local.get(['emojiUsage', TRASH_RECORDS_KEY, TRASH_FOLDER_ID_KEY, SORT_MODE_KEY])
  ]);
  state.tree = tree[0]; 
  state.colours = stored;
  state.usage = local.emojiUsage && typeof local.emojiUsage === 'object' ? local.emojiUsage : {};
  state.trashRecords = local[TRASH_RECORDS_KEY] && typeof local[TRASH_RECORDS_KEY] === 'object' ? local[TRASH_RECORDS_KEY] : {};
  state.sortMode = ['alphabetical', 'reverse-alphabetical', 'recent', 'reverse-recency'].includes(local[SORT_MODE_KEY])
    ? local[SORT_MODE_KEY]
    : 'alphabetical';
  updateSortButtons();
  const storedTrash = local[TRASH_FOLDER_ID_KEY] ? findNode(local[TRASH_FOLDER_ID_KEY]) : null;
  state.trashFolderId = storedTrash && !storedTrash.url ? storedTrash.id : (findTrashFolder()?.id || null);
  
  if (!findNode(state.folderId)) state.folderId = state.tree.children?.[0]?.id || '0';
  
  renderFolderTree(); 
  renderBreadcrumbs(); 
  renderCurrentFolder(); 
  renderSuggestions();
  updateTrashShortcut();
}

function updateTrashShortcut() {
  const isTrashActive = state.folderId === state.trashFolderId;
  $('#trashShortcut').classList.toggle('active', isTrashActive);
}

function updateSortButtons() {
  document.querySelectorAll('[data-sort-mode]').forEach(button => {
    const active = button.dataset.sortMode === state.sortMode;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}

async function navigateToTrash() {
  const trash = await ensureTrashFolder();
  selectFolder(trash.id);
}

function findTrashFolder() {
  let match = null;
  const walk = node => {
    if (match) return;
    if (!node.url && (node.title === TRASH_TITLE || LEGACY_TRASH_TITLES.has(node.title))) match = node;
    (node.children || []).forEach(walk);
  };
  (state.tree?.children || []).forEach(walk);
  return match;
}

function findNode(id, node = state.tree) {
  if (!node) return null;
  if (node.id === id) return node;
  for (const child of node.children || []) { 
    const found = findNode(id, child); 
    if (found) return found; 
  }
  return null;
}

function folderRoots() { 
  return (state.tree.children || []).filter(node => !node.url); 
}

function renderFolderTree() {
  const fragment = document.createDocumentFragment();
  sortItems(folderRoots()).forEach(root => fragment.appendChild(makeTreeBranch(root, 0)));
  $('#folderTree').replaceChildren(fragment);
}

function makeTreeBranch(folder, depth) {
  const wrapper = document.createElement('div');
  const childFolders = sortItems((folder.children || []).filter(node => !node.url));
  const row = document.createElement('div'); 
  row.className = `tree-row${folder.id === state.folderId ? ' active' : ''}`; 
  row.style.paddingLeft = `${10 + depth * 16}px`;
  
  const toggle = document.createElement('button'); 
  toggle.type = 'button'; 
  toggle.textContent = childFolders.length ? (state.expanded.has(folder.id) ? '▾' : '▸') : '';
  toggle.setAttribute('aria-label', 'Expand folder'); 
  toggle.addEventListener('click', event => { 
    event.stopPropagation(); 
    state.expanded.has(folder.id) ? state.expanded.delete(folder.id) : state.expanded.add(folder.id); 
    renderFolderTree(); 
  });
  
  const icon = document.createElement('span'); 
  icon.textContent = folder.id === state.trashFolderId ? '🗑️' : '📁';
  const title = document.createElement('span'); 
  title.className = 'tree-title'; 
  title.textContent = folder.title || 'Bookmarks'; 
  title.style.color = state.colours[colourKey(folder.id)] || '';
  
  row.append(toggle, icon, title); 
  row.addEventListener('click', () => selectFolder(folder.id)); 
  row.addEventListener('dragover', event => {
    if (!state.selected.size || state.selected.has(folder.id)) return;
    event.preventDefault();
    row.classList.add('drop-target');
  });
  row.addEventListener('dragleave', () => row.classList.remove('drop-target'));
  row.addEventListener('drop', async event => {
    event.preventDefault();
    row.classList.remove('drop-target');
    folder.id === state.trashFolderId
      ? await moveSelectionToTrash()
      : await moveSelectedItems(folder.id);
  });
  wrapper.append(row);
  
  if (state.expanded.has(folder.id)) {
    childFolders.forEach(child => wrapper.appendChild(makeTreeBranch(child, depth + 1)));
  }
  return wrapper;
}

function selectFolder(id) { 
  state.folderId = id; 
  $('#searchInput').value = ''; 
  clearSelection();
  renderFolderTree(); 
  renderBreadcrumbs(); 
  renderCurrentFolder(); 
  updateTrashShortcut();
}

function renderBreadcrumbs() {
  const parts = []; 
  let node = findNode(state.folderId);
  while (node && node.id !== '0') { 
    parts.unshift(node); 
    node = findNode(node.parentId); 
  }
  const fragment = document.createDocumentFragment();
  parts.forEach((part, index) => {
    if (index) { 
      const sep = document.createElement('span'); 
      sep.className = 'separator'; 
      sep.textContent = '›'; 
      fragment.append(sep); 
    }
    const button = document.createElement('button'); 
    button.className = `crumb${index === parts.length - 1 ? ' current' : ''}`; 
    button.textContent = part.title || 'Bookmarks';
    if (index < parts.length - 1) button.addEventListener('click', () => selectFolder(part.id));
    fragment.append(button);
  });
  $('#breadcrumbs').replaceChildren(fragment);
}

function renderCurrentFolder() {
  const folder = findNode(state.folderId); 
  renderItems(folder?.children || []);
}

async function handleSearch() {
  const query = $('#searchInput').value.trim();
  if (!query) { 
    renderCurrentFolder(); 
    return; 
  }
  renderItems(await chrome.bookmarks.search(query));
}

function renderItems(items) {
  const sorted = sortItems(items);
  state.visibleItems = sorted;
  state.selected = new Set([...state.selected].filter(id => sorted.some(item => item.id === id)));
  $('#itemList').replaceChildren(...sorted.map(makeItemRow));
  $('#emptyState').hidden = sorted.length > 0;
  updateSelectionBar();
}

function sortTitle(item) {
  return stripLeadingEmoji(item.title || '').trim().toLocaleLowerCase();
}

function sortItems(items) {
  const mode = state.sortMode;
  return [...items].sort((a, b) => {
    const typeOrder = Number(Boolean(a.url)) - Number(Boolean(b.url));
    if (typeOrder) return typeOrder;
    const titleOrder = sortTitle(a).localeCompare(sortTitle(b), undefined, {numeric: true, sensitivity: 'base'});
    if (mode === 'reverse-alphabetical') return -titleOrder;
    if (mode === 'recent' || mode === 'reverse-recency') {
      const dateOrder = (Number(b.dateAdded) || 0) - (Number(a.dateAdded) || 0);
      const orderedDate = mode === 'recent' ? dateOrder : -dateOrder;
      return orderedDate || titleOrder;
    }
    return titleOrder;
  });
}

function makeItemRow(item) {
  const row = document.createElement('div'); 
  row.className = `item-row${state.selected.has(item.id) ? ' selected' : ''}`;
  row.dataset.id = item.id;
  row.tabIndex = 0;
  row.draggable = true;
  row.setAttribute('aria-selected', String(state.selected.has(item.id)));
  const main = document.createElement('div'); 
  main.className = 'item-main'; 
  main.title = item.url || 'Open folder';
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.className = 'select-box';
  checkbox.checked = state.selected.has(item.id);
  checkbox.setAttribute('aria-label', `Select ${item.title || 'item'}`);
  const icon = document.createElement('span'); 
  icon.className = 'item-icon'; 
  icon.textContent = item.url ? '🔗' : '📁';
  const text = document.createElement('div'); 
  text.className = 'item-text';
  const title = document.createElement('div'); 
  title.className = 'item-title'; 
  title.textContent = item.title || (item.url ? item.url : 'Untitled folder');
  if (!item.url) title.style.color = state.colours[colourKey(item.id)] || '';
  text.append(title);
  if (item.url) { 
    const url = document.createElement('div'); 
    url.className = 'item-url'; 
    url.textContent = item.url; 
    text.append(url); 
  }
  const location = document.createElement('div');
  location.className = 'item-location';
  location.textContent = folderPath(item.parentId);
  location.title = `Location: ${location.textContent}`;
  text.append(location);
  main.append(checkbox,icon,text);
  row.addEventListener('click', event => {
    if (event.target.closest('.actions')) return;
    handleItemSelection(event, item);
  });
  row.addEventListener('dblclick', event => {
    if (event.target.closest('.actions') || event.target.classList.contains('select-box')) return;
    event.preventDefault();
    item.url ? window.open(item.url, '_blank', 'noopener') : selectFolder(item.id);
  });
  row.addEventListener('dragstart', event => {
    if (!state.selected.has(item.id)) selectOnly(item.id);
    row.classList.add('dragging');
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', [...state.selected].join(','));
  });
  row.addEventListener('dragend', () => {
    row.classList.remove('dragging');
    document.querySelectorAll('.drop-target').forEach(target => target.classList.remove('drop-target'));
  });
  if (!item.url) {
    row.addEventListener('dragover', event => {
      if (!canDropOnFolder(item.id)) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = 'move';
      row.classList.add('drop-target');
    });
    row.addEventListener('dragleave', event => {
      if (!row.contains(event.relatedTarget)) row.classList.remove('drop-target');
    });
    row.addEventListener('drop', async event => {
      event.preventDefault();
      event.stopPropagation();
      row.classList.remove('drop-target');
      if (!canDropOnFolder(item.id)) return;
      item.id === state.trashFolderId
        ? await moveSelectionToTrash()
        : await moveSelectedItems(item.id);
    });
  }
  
  const actions = document.createElement('div'); 
  actions.className = 'actions';
  if (item.id === state.trashFolderId) {
    actions.append(actionButton('→','Open Trash',() => selectFolder(item.id)));
  } else if (state.folderId === state.trashFolderId) {
    actions.append(
      actionButton('↩','Restore',() => restoreItems([item.id])),
      actionButton('🗑','Delete permanently',() => deletePermanently([item.id]))
    );
  } else {
    actions.append(
      actionButton('✎','Edit',() => openEditor('edit', item)), 
      actionButton('↪','Move',() => openMove(item),'move-action'), 
      actionButton('🗑','Move to Trash',() => moveItemsToTrash([item.id]))
    );
  }
  row.append(main,actions); 
  return row;
}

function handleItemSelection(event, item) {
  if (event.target.classList.contains('select-box')) {
    state.selected.has(item.id) ? state.selected.delete(item.id) : state.selected.add(item.id);
    state.selectionAnchorId = item.id;
  } else if (event.shiftKey && state.selectionAnchorId) {
    const anchor = state.visibleItems.findIndex(entry => entry.id === state.selectionAnchorId);
    const current = state.visibleItems.findIndex(entry => entry.id === item.id);
    if (anchor >= 0 && current >= 0) {
      if (!event.ctrlKey && !event.metaKey) state.selected.clear();
      const [start, end] = anchor < current ? [anchor, current] : [current, anchor];
      state.visibleItems.slice(start, end + 1).forEach(entry => state.selected.add(entry.id));
    }
  } else if (event.ctrlKey || event.metaKey) {
    state.selected.has(item.id) ? state.selected.delete(item.id) : state.selected.add(item.id);
    state.selectionAnchorId = item.id;
  } else {
    selectOnly(item.id);
    return;
  }
  state.allVisibleSelected = state.visibleItems.length > 0 && state.visibleItems.every(entry => state.selected.has(entry.id));
  syncSelectionStyles();
}

function selectOnly(id) {
  state.selected = new Set([id]);
  state.selectionAnchorId = id;
  state.allVisibleSelected = state.visibleItems.length === 1;
  syncSelectionStyles();
}

function clearSelection() {
  state.selected.clear();
  state.selectionAnchorId = null;
  state.allVisibleSelected = false;
  syncSelectionStyles();
}

function selectAllVisible() {
  state.selected = new Set(state.visibleItems.map(item => item.id));
  state.selectionAnchorId = state.visibleItems[0]?.id || null;
  state.allVisibleSelected = state.visibleItems.length > 0;
  syncSelectionStyles();
}

function syncSelectionStyles() {
  document.querySelectorAll('.item-row').forEach(row => {
    const selected = state.selected.has(row.dataset.id);
    row.classList.toggle('selected', selected);
    row.setAttribute('aria-selected', String(selected));
    const checkbox = row.querySelector('.select-box');
    if (checkbox) checkbox.checked = selected;
  });
  updateSelectionBar();
}

function updateSelectionBar() {
  const count = state.selected.size;
  const inTrash = state.folderId === state.trashFolderId;
  $('#selectionBar').hidden = count === 0;
  $('#selectionCount').textContent = `${count} ${count === 1 ? 'item' : 'items'} selected`;
  $('#selectionWarning').textContent = state.allVisibleSelected
    ? `All ${count} visible items in this folder are selected. Choose an action, or Clear Selection to close this bar. Actions affecting folders also affect everything inside them.`
    : 'Choose an action, or Clear Selection to close this bar. Actions affecting selected folders also affect everything inside them.';
  $('#moveSelectionButton').hidden = false;
  $('#moveSelectionButton').textContent = inTrash ? 'Restore Selected' : 'Move Selected';
  $('#moveSelectionButton').onclick = inTrash
    ? () => restoreItems([...state.selected])
    : () => openMove();
  $('#trashSelectionButton').textContent = inTrash ? 'Delete Permanently' : 'Move to Trash';
  $('#trashSelectionButton').onclick = inTrash
    ? () => deletePermanently([...state.selected])
    : moveSelectionToTrash;
}

function handleKeyboardSelection(event) {
  const target = event.target;
  const typing = target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement;
  if (typing || $('#editorDialog').open || $('#moveDialog').open) return;
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'a') {
    event.preventDefault();
    selectAllVisible();
  } else if (event.key === 'Escape' && state.selected.size) {
    clearSelection();
  } else if (event.key === 'Delete' && state.selected.size) {
    event.preventDefault();
    state.folderId === state.trashFolderId
      ? deletePermanently([...state.selected])
      : moveSelectionToTrash();
  }
}

function actionButton(symbol,label,handler,extra='') { 
  const button = document.createElement('button'); 
  button.type='button'; 
  button.className=`icon-button ${extra}`; 
  button.textContent=symbol; 
  button.title=label; 
  button.setAttribute('aria-label',label); 
  button.addEventListener('click', event => {
    event.stopPropagation();
    handler(event);
  }); 
  return button; 
}

function openEditor(mode, item = null) {
  state.mode = mode; 
  state.editing = item; 
  const folderMode = mode === 'new-folder' || (mode === 'edit' && item && !item.url);
  
  $('#dialogTitle').textContent = mode === 'edit' ? (folderMode ? 'Edit Folder' : 'Edit Bookmark') : (folderMode ? 'New Folder' : 'New Bookmark');
  $('#nameFieldLabel').textContent = folderMode ? 'Folder Emoji & Name' : 'Bookmark Title';
  $('#titleInput').value = item?.title || '';
  $('#urlInput').value = item?.url || '';
  $('#urlInput').disabled = folderMode;
  $('#urlInput').required = !folderMode;
  $('#urlField').hidden = folderMode; 
  $('#colourSection').hidden = !folderMode; 
  state.lastEmoji = '';
  selectColour(item ? (state.colours[colourKey(item.id)] || COLOURS[0][0]) : COLOURS[0][0]);
  renderSuggestions();
  renderInterestPack();
  $('#editorDialog').showModal(); 
  setTimeout(() => $('#titleInput').focus(), 0);
}

function applyEmoji(emoji) {
  const input=$('#titleInput'); 
  input.value=`${emoji} ${stripLeadingEmoji(input.value)}`.trim(); 
  input.focus();
  state.lastEmoji = emoji; 
  state.usage[emoji] = (state.usage[emoji] || 0) + 1;
  chrome.storage.local.set({emojiUsage:state.usage});
  renderSuggestions(); 
  renderInterestPack(); 
}

function removeLeadingEmoji() { 
  $('#titleInput').value = stripLeadingEmoji($('#titleInput').value); 
}

function stripLeadingEmoji(value) { 
  return value.replace(/^\s*(?:\p{Extended_Pictographic}|\p{Emoji_Presentation}|[‍️])+\s*/u,'').trimStart(); 
}

function selectColour(colour) { 
  state.selectedColour=colour; 
  $('#customColour').value=colour; 
  document.querySelectorAll('.colour-button').forEach(b=>b.classList.toggle('selected',b.dataset.colour.toLowerCase()===colour.toLowerCase())); 
}

async function saveEditor(event) {
  event.preventDefault(); 
  const title=$('#titleInput').value.trim(); 
  if (!title) return;
  const folderMode = state.mode === 'new-folder' || (state.mode === 'edit' && state.editing && !state.editing.url);
  const folderNameChanged = state.mode === 'new-folder' || normaliseFolderName(title) !== normaliseFolderName(state.editing?.title || '');
  if (folderMode && folderNameChanged && !confirmDuplicateFolder(title, state.editing?.id || null)) return;
  try {
    let item;
    if (state.mode === 'edit') item = await chrome.bookmarks.update(state.editing.id, state.editing.url ? {title,url:normaliseUrl($('#urlInput').value)} : {title});
    else if (state.mode === 'new-folder') item = await chrome.bookmarks.create({parentId:state.folderId,title});
    else item = await chrome.bookmarks.create({parentId:state.folderId,title,url:normaliseUrl($('#urlInput').value)});
    if (!item.url) await chrome.storage.sync.set({[colourKey(item.id)]:state.selectedColour});
    $('#editorDialog').close(); 
    toast('Saved changes'); 
    await refresh();
  } catch(error) { 
    toast(error.message || 'Could not save'); 
  }
}

function normaliseUrl(value) { 
  const url=value.trim(); 
  if (!url) throw new Error('Enter a URL'); 
  return /^[a-z][a-z0-9+.-]*:/i.test(url) ? url : `https://${url}`; 
}

function normaliseFolderName(value) {
  return stripLeadingEmoji(value || '').trim().replace(/\s+/g, ' ').toLocaleLowerCase();
}

function allFolders() {
  const folders = [];
  const walk = node => {
    if (!node.url && node.id !== '0') folders.push(node);
    (node.children || []).forEach(walk);
  };
  (state.tree?.children || []).forEach(walk);
  return folders;
}

function folderPath(folderId, includeSelf = true) {
  const parts = [];
  let node = findNode(folderId);
  while (node && node.id !== '0') {
    if (includeSelf || parts.length > 0) parts.unshift(node.title || 'Bookmarks');
    node = findNode(node.parentId);
  }
  return parts.join(' › ') || 'Bookmark roots';
}

function confirmDuplicateFolder(title, excludeId = null) {
  const normalised = normaliseFolderName(title);
  if (!normalised) return true;
  const matches = allFolders().filter(folder => folder.id !== excludeId && normaliseFolderName(folder.title) === normalised);
  if (!matches.length) return true;
  const displayed = matches.slice(0, 6).map(folder => `• ${folderPath(folder.id)}`).join('\n');
  const remaining = matches.length > 6 ? `\n• and ${matches.length - 6} more` : '';
  return confirm(`A folder with this name already exists.\n\nExisting location${matches.length === 1 ? '' : 's'}:\n${displayed}${remaining}\n\nCreate or rename this folder anyway?`);
}

function openMove(item = null) {
  const ids = item ? [item.id] : [...state.selected];
  if (!ids.length) return;
  state.moving = item;
  state.movingIds = topLevelSelection(ids).filter(id => id !== state.trashFolderId);
  if (!state.movingIds.length) return;
  const destinations=[];
  const walk=(node,depth=0)=>{ 
    if (!node.url && node.id!=='0' && node.id !== state.trashFolderId && !isNodeWithinSelection(node.id, state.movingIds)) {
      destinations.push({id: node.id, title: node.title || 'Bookmarks', depth, path: folderPath(node.id)}); 
    } 
    (node.children||[]).forEach(child=>{if(!child.url)walk(child,depth+1);}); 
  };
  folderRoots().forEach(root=>walk(root)); 
  state.moveDestinations = destinations;
  $('#moveSearch').value = '';
  renderMoveDestinations();
  $('#moveDialog').showModal();
  setTimeout(() => $('#moveSearch').focus(), 0);
}

function renderMoveDestinations(query = '') {
  const words = query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  const matches = state.moveDestinations.filter(destination => {
    const searchable = `${destination.title} ${destination.path}`.toLocaleLowerCase();
    return words.every(word => searchable.includes(word));
  });
  const options = matches.map(destination => {
    const option = document.createElement('option');
    option.value = destination.id;
    option.textContent = `${'\u00A0\u00A0'.repeat(destination.depth)}📁 ${destination.title}`;
    option.title = destination.path;
    if (destination.id === state.folderId) option.selected = true;
    return option;
  });
  if (!options.length) {
    const empty = document.createElement('option');
    empty.disabled = true;
    empty.textContent = 'No matching folders';
    options.push(empty);
  }
  $('#moveDestination').replaceChildren(...options);
}

async function saveMove(event) { 
  event.preventDefault(); 
  try { 
    const destinationId = $('#moveDestination').value;
    if (!destinationId) throw new Error('Choose a destination folder');
    await moveItems(state.movingIds, destinationId);
    $('#moveDialog').close(); 
    toast(`${state.movingIds.length} ${state.movingIds.length === 1 ? 'item' : 'items'} moved`);
    await refresh();
    clearSelection();
    state.moving = null;
    state.movingIds = [];
  } catch(error) { 
    toast(error.message || 'Could not move item'); 
  } 
}

function isNodeWithinSelection(nodeId, selectedIds) {
  if (selectedIds.includes(nodeId)) return true;
  let node = findNode(nodeId);
  while (node?.parentId) {
    if (selectedIds.includes(node.parentId)) return true;
    node = findNode(node.parentId);
  }
  return false;
}

function canDropOnFolder(folderId) {
  if (!state.selected.size || state.selected.has(folderId)) return false;
  return topLevelSelection([...state.selected]).every(sourceId =>
    sourceId !== folderId && !isNodeWithinSelection(folderId, [sourceId])
  );
}

function topLevelSelection(ids) {
  const selected = new Set(ids);
  return ids.filter(id => {
    let node = findNode(id);
    while (node?.parentId) {
      if (selected.has(node.parentId)) return false;
      node = findNode(node.parentId);
    }
    return true;
  });
}

async function moveItems(ids, parentId) {
  for (const id of topLevelSelection(ids)) {
    if (id === parentId || isNodeWithinSelection(parentId, [id])) throw new Error('A folder cannot be moved inside itself');
    await chrome.bookmarks.move(id, {parentId});
  }
}

async function moveSelectedItems(parentId) {
  if (!state.selected.size) return;
  try {
    const ids = topLevelSelection([...state.selected]).filter(id => id !== state.trashFolderId);
    if (!ids.length) throw new Error('Trash is protected and cannot be moved');
    await moveItems(ids, parentId);
    toast(`${ids.length} ${ids.length === 1 ? 'item' : 'items'} moved`);
    await refresh();
    clearSelection();
  } catch (error) {
    toast(error.message || 'Could not move selected items');
  }
}

function affectedCount(node) {
  return 1 + (node.children || []).reduce((total, child) => total + affectedCount(child), 0);
}

function selectionSummary(ids) {
  const nodes = topLevelSelection(ids).map(id => findNode(id)).filter(Boolean);
  const folders = nodes.filter(node => !node.url).length;
  const bookmarks = nodes.length - folders;
  const total = nodes.reduce((sum, node) => sum + affectedCount(node), 0);
  return {nodes, folders, bookmarks, total, contained: total - nodes.length};
}

async function ensureTrashFolder() {
  const existing = findTrashFolder();
  if (existing) {
    if (existing.title !== TRASH_TITLE) {
      await chrome.bookmarks.update(existing.id, {title: TRASH_TITLE});
      existing.title = TRASH_TITLE;
    }
    state.trashFolderId = existing.id;
    await chrome.storage.local.set({[TRASH_FOLDER_ID_KEY]: existing.id});
    return existing;
  }
  const roots = folderRoots();
  const parent = roots.find(root => root.id === '2' || /other bookmarks/i.test(root.title)) || roots[0];
  if (!parent) throw new Error('No suitable bookmark location is available for FolderMoji Trash');
  const created = await chrome.bookmarks.create({parentId: parent.id, title: TRASH_TITLE});
  state.trashFolderId = created.id;
  await chrome.storage.local.set({[TRASH_FOLDER_ID_KEY]: created.id});
  return created;
}

function confirmLargeOperation(summary, actionLabel) {
  const details = `${summary.folders} ${summary.folders === 1 ? 'folder' : 'folders'}, ${summary.bookmarks} ${summary.bookmarks === 1 ? 'bookmark' : 'bookmarks'}`;
  const nested = summary.contained ? `\nThe selected folders contain ${summary.contained} additional items.` : '';
  if (!confirm(`${actionLabel} ${summary.nodes.length} selected items?\n\nSelected: ${details}.${nested}\nTotal affected: ${summary.total}.`)) return false;
  if (summary.total >= 100) {
    const phrase = `CONFIRM ${summary.total}`;
    return prompt(`Large operation warning. Type ${phrase} to continue.`) === phrase;
  }
  return true;
}

function moveSelectionToTrash() {
  return moveItemsToTrash([...state.selected]);
}

async function moveItemsToTrash(ids) {
  const safeIds = topLevelSelection(ids).filter(id => id !== state.trashFolderId);
  if (!safeIds.length) return;
  const summary = selectionSummary(safeIds);
  if (!confirmLargeOperation(summary, 'Move to FolderMoji Trash:')) return;
  try {
    const trash = await ensureTrashFolder();
    for (const node of summary.nodes) {
      state.trashRecords[node.id] = {parentId: node.parentId, index: node.index, deletedAt: new Date().toISOString()};
      await chrome.bookmarks.move(node.id, {parentId: trash.id});
    }
    await chrome.storage.local.set({[TRASH_RECORDS_KEY]: state.trashRecords});
    clearSelection();
    toast(`${summary.total} ${summary.total === 1 ? 'item' : 'items'} moved to FolderMoji Trash`);
    await refresh();
  } catch (error) {
    toast(error.message || 'Could not move items to Trash');
  }
}

async function restoreItems(ids) {
  const restoreIds = topLevelSelection(ids);
  if (!restoreIds.length) return;
  try {
    const fallback = folderRoots().find(root => root.id === '2' || /other bookmarks/i.test(root.title)) || folderRoots()[0];
    for (const id of restoreIds) {
      const record = state.trashRecords[id] || {};
      const destination = findNode(record.parentId) && record.parentId !== state.trashFolderId ? record.parentId : fallback?.id;
      if (!destination) throw new Error('No restore location is available');
      const destinationNode = findNode(destination);
      const safeIndex = Number.isInteger(record.index) ? Math.min(record.index, destinationNode?.children?.length || 0) : null;
      await chrome.bookmarks.move(id, {parentId: destination, ...(safeIndex !== null ? {index: safeIndex} : {})});
      delete state.trashRecords[id];
    }
    await chrome.storage.local.set({[TRASH_RECORDS_KEY]: state.trashRecords});
    clearSelection();
    toast(`${restoreIds.length} ${restoreIds.length === 1 ? 'item' : 'items'} restored`);
    await refresh();
  } catch (error) {
    toast(error.message || 'Could not restore items');
  }
}

async function deletePermanently(ids) {
  const safeIds = topLevelSelection(ids);
  const summary = selectionSummary(safeIds);
  if (!summary.nodes.length) return;
  if (!confirm(`Permanently delete ${summary.total} ${summary.total === 1 ? 'item' : 'items'}?\n\nThis cannot be undone and the items will not go to the Windows Recycle Bin.`)) return;
  if (summary.total >= 10) {
    const phrase = `PERMANENTLY DELETE ${summary.total}`;
    if (prompt(`Permanent deletion warning. Type ${phrase} to continue.`) !== phrase) return;
  }
  try {
    for (const node of summary.nodes) {
      node.url ? await chrome.bookmarks.remove(node.id) : await chrome.bookmarks.removeTree(node.id);
      delete state.trashRecords[node.id];
      if (!node.url) await chrome.storage.sync.remove(colourKey(node.id));
    }
    await chrome.storage.local.set({[TRASH_RECORDS_KEY]: state.trashRecords});
    clearSelection();
    toast(`${summary.total} ${summary.total === 1 ? 'item' : 'items'} permanently deleted`);
    await refresh();
  } catch (error) {
    toast(error.message || 'Could not delete items');
  }
}

let toastTimer; 
function toast(message){ 
  const el=$('#toast'); 
  el.textContent=message; 
  el.classList.add('show'); 
  clearTimeout(toastTimer); 
  toastTimer=setTimeout(()=>el.classList.remove('show'),2200); 
}

function debounce(fn,delay){
  let timer;
  return(...args)=>{
    clearTimeout(timer);
    timer=setTimeout(()=>fn(...args),delay);
  };
}
